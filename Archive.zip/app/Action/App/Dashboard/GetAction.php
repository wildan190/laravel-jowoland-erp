<?php

namespace App\Action\App\Dashboard;

class GetAction
{
    public function execute(): array
    {
        return ['message' => 'Welcome to your Dashboard!'];
    }
}
