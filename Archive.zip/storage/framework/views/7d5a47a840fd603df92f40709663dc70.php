<?php $__env->startSection('title', 'Edit Deal'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item"><a href="<?php echo e(route('deal.index')); ?>">Deals</a></li>
                <li class="breadcrumb-item active" aria-current="page">Edit</li>
            </ol>
        </nav>

        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('deal.update', $deal)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label for="title" class="form-label">Judul</label>
                        <input type="text" name="title" id="title" class="form-control" value="<?php echo e($deal->title); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="value" class="form-label">Nilai</label>
                        <input type="number" name="value" id="value" class="form-control" value="<?php echo e($deal->value); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="contact_id" class="form-label">Kontak</label>
                        <select name="contact_id" id="contact_id" class="form-select">
                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($contact->id); ?>" <?php echo e($contact->id == $deal->contact_id ? 'selected' : ''); ?>>
                                    <?php echo e($contact->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="pipeline_stage_id" class="form-label">Stage</label>
                        <select name="pipeline_stage_id" id="pipeline_stage_id" class="form-select">
                            <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($stage->id); ?>" <?php echo e($stage->id == $deal->pipeline_stage_id ? 'selected' : ''); ?>>
                                    <?php echo e($stage->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-select">
                            <option value="open" <?php echo e($deal->status == 'open' ? 'selected' : ''); ?>>Open</option>
                            <option value="won" <?php echo e($deal->status == 'won' ? 'selected' : ''); ?>>Won</option>
                            <option value="lost" <?php echo e($deal->status == 'lost' ? 'selected' : ''); ?>>Lost</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="notes" class="form-label">Catatan</label>
                        <textarea name="notes" id="notes" class="form-control" rows="3"><?php echo e($deal->notes); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-success">Update</button>
                    <a href="<?php echo e(route('deal.index')); ?>" class="btn btn-secondary">Batal</a>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/wildanbelfiore/freelance_project/laravel-jowoland-erp/resources/views/crm/deals/edit.blade.php ENDPATH**/ ?>